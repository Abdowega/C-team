#ifndef ACTIONEDIT_H
#define ACTIONEDIT_H
#include "Action.h"
#include "..\Components\Resistor.h"
#include "..\Components\Buzzer.h"
#include "..\Components\Bulb.h"
#include "..\Components\Component.h"


class ActionEdit : public Action
{

public:
	ActionEdit(ApplicationManager* pApp);
	virtual ~ActionEdit(void);

	
	virtual void Execute();

	virtual void Undo();
	virtual void Redo();
};
#endif