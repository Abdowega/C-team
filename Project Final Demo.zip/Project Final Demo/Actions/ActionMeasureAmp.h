#ifndef ActionMeasureAmp_H
#define ActionMeasureAmp_H
#include "Action.h"
#include "..\Components\Battery.h"


//Class responsible for adding a new resistor action
class ActionMeasureAmp : public Action
{
private:
	//Parameters for rectangular area to be occupied by the comp
	int Cx, Cy;	//Center point of the comp
	int x1, y1, x2, y2;	//Two corners of the rectangluar area
public:
	ActionMeasureAmp(ApplicationManager* pApp);
	virtual ~ActionMeasureAmp(void);

	//Execute action (code depends on action type)
	virtual void Execute();

	virtual void ActionMeasureAmp::Undo();

	virtual void ActionMeasureAmp::Redo();
};
#endif
