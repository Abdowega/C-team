#include "ActionMeasureVolt.h"
#include "..\ApplicationManager.h"
#include "..\UI\UI.h"
ActionMeasureVolt::ActionMeasureVolt(ApplicationManager* pApp) :Action(pApp)
{
}

ActionMeasureVolt::~ActionMeasureVolt(void)
{
}

void ActionMeasureVolt::Execute()
{


}

void ActionMeasureVolt::Undo()
{}

void ActionMeasureVolt::Redo()
{}
