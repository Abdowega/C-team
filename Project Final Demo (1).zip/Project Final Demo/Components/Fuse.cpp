#include "..\ApplicationManager.h"
#include "..\UI\UI.h"
#include "..\Actions\Action.h"
#include "Fuse.h"
#include <stdlib.h>


Fuse::Fuse(GraphicsInfo* r_GfxInfo)
{
}

void Fuse::Draw(UI* pUI)
{
	int xlabel = m_pGfxInfo->PointsList[0].x;
	int ylabel = m_pGfxInfo->PointsList[0].y + 50;

	pUI->labelMsg(getlabel(), xlabel, ylabel);
	pUI->DrawFuse(*m_pGfxInfo, selected);




}

void Fuse::Operate()
{

}

void Fuse::Load(int Value, string)
{
}

void Fuse::SaveCircuit(ofstream& CircuitFile)
{
}

ALLCOMPS Fuse::whichComponent() {
	return 	FUSE;
}