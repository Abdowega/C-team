#include "ActionMeasureVolt.h"
#include "..\ApplicationManager.h"
#include "..\UI\UI.h"
ActionMeasureVolt::ActionMeasureVolt(ApplicationManager* pApp) :Action(pApp)
{
}


ActionMeasureVolt::~ActionMeasureVolt(void)
{
}

void ActionMeasureVolt::Execute()
{
	//Get a Pointer to the user Interfaces
	UI* pUI = pManager->GetUI();
	pUI->PrintMsg("Select the component to Measure");
	int x, y;

	pUI->GetPointClicked(x, y);
	Component* comp1 = pManager->GetComponentByCordinates(x, y);
	pUI->ClearStatusBar();
	comp1 = pManager->GetComponentByCordinates(x, y);

	pUI->ClearStatusBar();
	//Print Action Message
	pUI->PrintMsg("Measuring Volt...");
	pUI->PrintMsg("The Volt is 5");
	pUI->GetPointClicked(x, y);
	pUI->ClearStatusBar();

}

void ActionMeasureVolt::Undo()
{}

void ActionMeasureVolt::Redo()
{}
