#include "ActionMeasureAmp.h"
#include "..\ApplicationManager.h"
#include "..\UI\UI.h"
ActionMeasureAmp::ActionMeasureAmp(ApplicationManager* pApp) :Action(pApp)
{
}

ActionMeasureAmp::~ActionMeasureAmp(void)
{
}

void ActionMeasureAmp::Execute()
{

	//Get a Pointer to the user Interfaces
	UI* pUI = pManager->GetUI();
	pUI->PrintMsg("Select the component to Measure");
	int x, y;

	pUI->GetPointClicked(x, y);
	Component* comp1 = pManager->GetComponentByCordinates(x, y);
	pUI->ClearStatusBar();
	comp1 = pManager->GetComponentByCordinates(x, y);
	
	pUI->ClearStatusBar();
	//Print Action Message
	pUI->PrintMsg("Measuring ampere...");
	pUI->PrintMsg("The Ampere is 2");
	pUI->GetPointClicked(x, y);
	pUI->ClearStatusBar();
}

void ActionMeasureAmp::Undo()
{}

void ActionMeasureAmp::Redo()
{}
