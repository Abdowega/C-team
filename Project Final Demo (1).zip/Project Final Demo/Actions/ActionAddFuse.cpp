#include "..\UI\UI.h"
#include "..\ApplicationManager.h"
#include "../Actions/ActionAddFuse.h"



ActionAddFuse::ActionAddFuse(ApplicationManager* pApp) :Action(pApp)
{
}

ActionAddFuse::~ActionAddFuse(void)
{
}

void ActionAddFuse::Execute()
{

	
	UI* pUI = pManager->GetUI();

	pUI->PrintMsg("Adding a new Fuse: Click anywhere to add");

	pUI->GetPointClicked(Cx, Cy);
	while (!(Cy > UI::getToolBarHeight() + UI::getCompHeight() / 2
		&& Cy < UI::Height() - UI::getStatusBarHeight() - UI::getCompHeight() / 2
		&& Cx > UI::getCompWidth() / 2
		&& Cx < UI::getWidth() - UI::getCompWidth() / 2)) {
		pUI->GetPointClicked(Cx, Cy);

	}

	pUI->ClearStatusBar();


	GraphicsInfo* pGInfo = new GraphicsInfo(2); 

	int compWidth = pUI->getCompWidth();
	int compHeight = pUI->getCompHeight();

	pGInfo->PointsList[0].x = Cx - compWidth / 2;
	pGInfo->PointsList[0].y = Cy - compHeight / 2;
	pGInfo->PointsList[1].x = Cx + compWidth / 2;
	pGInfo->PointsList[1].y = Cy + compHeight / 2;

	Fuse* pR = new Fuse(pGInfo);
	string value = pUI->GetSrting("Enter a resistance Value: The default value is 1","");
	while (value == "")
		value = pUI->GetSrting("Enter a resistance Value: The default value is 1","");
	pR->setresistance(stod(value));
	pUI->ClearStatusBar();

	pManager->AddComponent(pR);
}

void ActionAddFuse::Undo()
{}

void ActionAddFuse::Redo()
{}
