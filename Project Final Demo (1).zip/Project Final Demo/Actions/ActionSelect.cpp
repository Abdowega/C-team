#include "ActionSelect.h"
#include "../ApplicationManager.h"
#include "../UI/UI.h"
#include "../Defs.H"
ActionSelect::ActionSelect(ApplicationManager* pApp) :Action(pApp)
{
}

ActionSelect::~ActionSelect(void)
{
}
MODE AppMode;
void ActionSelect::Execute() {
	UI* pUI = pManager->GetUI();//Gets a pointer to the user interface
	x = pUI->getXtemp();//Gets the coordinates which the user clicked on
	y = pUI->getYtemp();
	Component* comp1 = pManager->GetComponentByCordinates(x, y);
	Connection* conn1 = pManager->GetConnByCordinates(x, y);
	if (comp1 != nullptr){
		
		//pManager->UnselectAll(comp1); //this line was used to make no more than one thing to be selected
		comp1->Selection();
		ALLCOMPS CompNumber = comp1->whichComponent();
		if (AppMode != DESIGN &&comp1->getCompState() == OPEN && CompNumber == SWITCH)
		{
			comp1->setState(CLOSED);
		}
		else if (AppMode != DESIGN && CompNumber == SWITCH)
		{
			comp1->setState(OPEN);
		}
	}
	else if (conn1 != nullptr) {
		
		//pManager->UnselectAll(conn1); 
		conn1->Selection();
	}

}
void ActionSelect::Undo()
{}

void ActionSelect::Redo()
{}