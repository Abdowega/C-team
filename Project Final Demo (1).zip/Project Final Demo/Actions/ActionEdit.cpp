#include<string> 
#include "..\ApplicationManager.h"
#include "..\UI\UI.h"
#include "ActionEdit.h"

 
ActionEdit::ActionEdit(ApplicationManager* pApp) :Action(pApp)
{
}

ActionEdit::~ActionEdit(void)
{
}
void ActionEdit::Execute()
{
	UI* pUI = pManager->GetUI();
	pUI->PrintMsg("Select the component or connections to edit");
	int x, y;

	pUI->GetPointClicked(x, y);
	Component* comp1 = pManager->GetComponentByCordinates(x,y);
	Connection* conn1 = pManager->GetConnByCordinates(x, y);
	
		pUI->ClearStatusBar();
		comp1 = pManager->GetComponentByCordinates(x, y);
		conn1 = pManager->GetConnByCordinates(x, y);
		if (comp1 != nullptr) {
			ALLCOMPS CompNumber = comp1->whichComponent();
			switch (CompNumber) {
			case RESISTOR:
			case BULB:
			case FUSE:
			case BUZZER:
			{
				string value;
				int intValue;
					do {
						value = pUI->GetSrting("enter 1 to edit the label, 2 to the edit the resistace value or 3 to cancel ", "");
					} while (value != "1" && value != "2" && value != "3");
					intValue = stod(value);
					switch (intValue) {
					case 1:
					{
						
						value = pUI->GetSrting(comp1->getLabel(), comp1->getLabel());
						comp1->setlabel(value);
						break;
					}
					case 2:
					{
						value = pUI->GetSrting(to_string(comp1->getResistance()), to_string(comp1->getResistance()));
						comp1->setresistance(stod(value));
						break;
					}
					case 3:
						break;
					}
					break;
					
			}
			
			case SWITCH:
			{	
				string value;
				int intValue;
				do {
					value = pUI->GetSrting("enter 1 to edit the label, 2 to the edit Switch status or 3 to cancel ", "");
				} while (value != "1" && value != "2" && value != "3");
				intValue = stod(value);
				switch (intValue) {
				case 1:
				{

					value = pUI->GetSrting(comp1->getLabel(), comp1->getLabel());
					comp1->setlabel(value);
					break;
				}
				case 2:
				{
					value = pUI->GetSrting(to_string(comp1->getCompState()), to_string(comp1->getCompState()));
					comp1->setState(stod(value));
					break;
				}
				case 3:
					break;
				}
				break;
			}
			case BATTERY:
			{	
				string value;
				int intValue;
				do {
					value = pUI->GetSrting("enter 1 to edit the label, 2 to the edit Battery voltage or 3 to cancel ", "");
				} while (value != "1" && value != "2" && value != "3");
				intValue = stod(value);
				switch (intValue) {
				case 1:
				{

					value = pUI->GetSrting(comp1->getLabel(), comp1->getLabel());
					comp1->setlabel(value);
					break;
				}
				case 2:
				{
					value = pUI->GetSrting(to_string(comp1->getSourceVoltage()), to_string(comp1->getSourceVoltage()));
					comp1->setSourceVoltage(stod(value));
					break;
				}
				case 3:
					break;
				}
				break;
			}
			case GROUND:
			{	
				string value;
				int intValue;
				do {
					value = pUI->GetSrting("enter 1 to edit the label or 2 to cancel ", "");
				} while (value != "1" && value != "2");
				intValue = stod(value);
				switch (intValue) {
				case 1:
				{

					value = pUI->GetSrting(comp1->getLabel(), comp1->getLabel());
					comp1->setlabel(value);
					break;
				}
				
				case 2:
					break;
				}
				break;
			}
			}
		}
		else if (conn1 != nullptr) {
		string value;
		int intValue;
		do {
			value = pUI->GetSrting("enter 1 to edit the label or 2 to change terminals or 3 to cancel ", "");
		} while (value != "1" && value != "2" && value != "3");
		intValue = stod(value);
		switch (intValue) {
		case 1:
		{

			value = pUI->GetSrting(conn1->getLabel(), conn1->getLabel());
			conn1->setLabel(value);
			break;
		}
		case 2: {
			int x, y;
			GraphicsInfo* G = new GraphicsInfo(2);
			G = conn1->getgraphics();
			pUI->PrintMsg("Select which terminals you want to change ");
			pUI->GetPointClicked(x, y);
			pUI->ClearStatusBar();
			Component* tempComp1 = pManager->GetComponentByCordinates(x, y);
			Component* tempComp2;
			if (tempComp1 != nullptr) {
				int compnum = conn1->WhichComp(tempComp1);
				if (compnum != 0) {
					pUI->PrintMsg("Select a component to connect to: ");
					pUI->GetPointClicked(x, y);
					pUI->ClearStatusBar();
					tempComp2 = pManager->GetComponentByCordinates(x, y);
					if (tempComp2 != nullptr) {
						tempComp1->deletecon(conn1);
						if (x > tempComp2->getCompCenterX(pUI)) {
							tempComp2->addTerm2Conn(conn1);
							G->PointsList[compnum - 1].x = tempComp2->getCompCenterX(pUI) + (pUI->getCompWidth() / 2);
							G->PointsList[compnum - 1].y = tempComp2->getCompCenterY(pUI);
						}
						else {
							tempComp2->addTerm1Conn(conn1);
							G->PointsList[compnum - 1].x = tempComp2->getCompCenterX(pUI) - (pUI->getCompWidth() / 2);
							G->PointsList[compnum - 1].y = tempComp2->getCompCenterY(pUI);

						}
						conn1->setNewComp(compnum, tempComp2);
					}
				}
			}
			break;
		}
		case 3:
			break;
		}
		}
	pUI->ClearStatusBar();
}
void ActionEdit::Undo()
{}

void ActionEdit::Redo()
{}